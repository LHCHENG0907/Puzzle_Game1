package entity;

import java.awt.Rectangle;
import attributes.Visitorble;
import attributes.Visitor;

// public class Entity implements Component {
// public Rectangle bounds = new Rectangle(0, 0, 0, 0);

// public Rectangle getBounds() {
// return bounds; // 回傳邊界
// }

// public void setBounds(int X, int Y, int Width, int Height) {
// bounds.setBounds(X, Y, Width, Height);// 設定邊界
// }

// public void setLocation(int X, int Y) {
// bounds.setLocation(X, Y);
// }

// @Override
// public void accept(Visitor v) {
// v.visit(this);
// }

// }