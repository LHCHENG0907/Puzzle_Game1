package entity;

public interface Visitor {
    void visit(ImageDisplay EntityItem);

    void visit(LockedBox EntityItem);
}
