package entity;

public interface Visitorble {
    void accept(Visitor v);
}
